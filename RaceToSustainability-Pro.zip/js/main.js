
document.querySelectorAll('.reveal').forEach(el=>{
 const io=new IntersectionObserver(entries=>{
  entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add('visible')})
 });
 io.observe(el);
});
